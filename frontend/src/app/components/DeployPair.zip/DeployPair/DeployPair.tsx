"use client";

import React, { useState, useEffect } from "react";
import { useAccount } from "wagmi";
import { useWriteContract, useContractWrite } from "wagmi";
import { ethers } from "ethers";
import { abi } from "./abi";
import { Address } from "viem";
import { useSendTransaction } from "wagmi";
import { parseEther, parseGwei } from "viem";
import { error } from "console";

// Your deployed contract addresses
const factoryAddress = "0xAc351584FCa597360CCb7984B29873A042361217";
const timeSwapMathAddress = "0x2f94c770761928E4E0d364AC3c888621F75E5E99";

const abi1 = [
  // Include your contract's ABI here. Specifically, the createPair function signature.
  {
    inputs: [
      { internalType: "address", name: "asset", type: "address" },
      { internalType: "address", name: "collateral", type: "address" },
    ],
    name: "createPair",
    outputs: [{ internalType: "address", name: "pair", type: "address" }],
    stateMutability: "nonpayable",
    type: "function",
  },
  // Add other necessary ABI details
];

const DeployPair: React.FC = () => {
  const {
    writeContract,
    isSuccess,
    data: writeContractData,
    status: writeContractStatus,
    error: contracterror,
  } = useWriteContract();
  const { address: userAddress } = useAccount();
  const [pairContractAddress, setPairContractAddress] = useState<string | null>(
    null
  );

  // State to handle input values for asset and collateral token addresses
  const [assetTokenAddress, setAssetTokenAddress] = useState<string>("");
  const [collateralTokenAddress, setCollateralTokenAddress] =
    useState<string>("");

  async function createPair() {
    console.log("creating pair");
    console.log("assetTokenAddress: ", assetTokenAddress);
    console.log("collateralTokenAddress: ", collateralTokenAddress);
    const gasPrice = ethers.utils.parseUnits("20", "gwei");
    try {
      writeContract({
        abi: abi1,
        address: "0x41790CF2FFA54FB6A3bb853dF0Fe7bd10A5F12c2",
        functionName: "createPair",
        args: [assetTokenAddress, collateralTokenAddress],
        gas: parseGwei("20"),
      });
      console.log("creating pair completed");
    } catch (e) {
      console.log("error: ", e);
    }
  }
  console.log("writeContractStatus: ", writeContractStatus);
  console.log("contracterror: ", contracterror);
  return (
    <div>
      <h2>Create Timeswap Pair</h2>

      <div style={{ marginBottom: "1rem" }}>
        <label>
          Asset Token Address:
          <input
            type="text"
            value={assetTokenAddress}
            onChange={(e) => setAssetTokenAddress(e.target.value)}
            placeholder="Enter Asset Token Address"
            style={{ marginLeft: "10px", padding: "5px" }}
          />
        </label>
      </div>

      <div style={{ marginBottom: "1rem" }}>
        <label>
          Collateral Token Address:
          <input
            type="text"
            value={collateralTokenAddress}
            onChange={(e) => setCollateralTokenAddress(e.target.value)}
            placeholder="Enter Collateral Token Address"
            style={{ marginLeft: "10px", padding: "5px" }}
          />
        </label>
      </div>

      <button
        onClick={createPair}
        style={{ padding: "10px 15px", cursor: "pointer" }}
        disabled={!createPair || !assetTokenAddress || !collateralTokenAddress}
      >
        Create Pair
      </button>

      {pairContractAddress && (
        <div>
          <h3>Pair Contract Address</h3>
          <p>{pairContractAddress}</p>
        </div>
      )}
    </div>
  );
};

export default DeployPair;
